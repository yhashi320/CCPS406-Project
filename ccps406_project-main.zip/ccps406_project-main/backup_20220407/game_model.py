class GameModel():

	def __init__(self):
		pass